import os
import spacy
import numpy as np
import gensim
import tensorflow as tf
import pickle
import re
import bs4


from bs4 import BeautifulSoup as soupe

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Flatten, Dense, Dropout, Activation



class SO_Tag_Predictor() :
    


    def __init__(self):

        self.model_w2v = FastText.load("Data/model_ft.bin")
        self.model = self.create_model()
        self.nlp = spacy.load('en_core_web_sm')
        self.std = pickle.load(open("Data/std.pickle", "rb"))
        self.pca = pickle.load(open("Data/pca.pickle", "rb"))
        self.labels = pickle.load(open("Data/labels.pickle", "rb"))
        self.lexique = self.model_w2v.wv.index2entity
    


    def tag_one_question(self, texte):
        
        t = self.soup_text(texte)
    
        tx = self.pipe_clsw(t, True, True)
    
        txt = self.text_from_tok([tx])

        tt = self.clean_for_gensim(txt)

        tx_we = self.make_gensim_vectors(tt, self.model_w2v)

        tx_std = self.std.transform(tx_we)

        tx_pca = self.pca.transform(tx_std)

        pred = self.model.predict(tx_pca).round()

        # On force une prédiction
        res = []

        if (pred > 0.5).sum() == 0 :

            res.append(self.labels[np.argmax(pred)])

        else :

            pred = pred.round()

            for n in np.nonzero(pred)[1].tolist():

                res.append(self.labels[n])

        return res
    

    
    def create_model(self):

        model = Sequential()

        model.add(Dense(75, input_shape = (75, )))
        model.add(Activation("relu"))
        model.add(Dropout(0.2))

        model.add(Dense(75))
        model.add(Activation("relu"))
        model.add(Dropout(0.2))

        model.add(Dense(25))
        model.add(Activation("sigmoid"))

        model.compile(loss='binary_crossentropy', optimizer="adam", metrics=accuracy)

        model.load_weights("Data/so_dl_01.hdf5")

        return model
    
    
     
    def soup_text(self, t):
    
        liste_sans_pre = []
        texte = ""

        soup = soupe(t)

        for cont in soup :

            if not cont.name or cont.name != "pre":

                liste_sans_pre.append(cont)

        for c in liste_sans_pre :

            if isinstance(c, bs4.element.Tag):

                texte = texte + c.text.replace("\n", "") + " "

            else :

                texte = texte + c.replace("\n", "") + " "

        texte = texte.rstrip()

        return texte.lower()   
    
    

    def clean_text(self, texte):

        char_gardes = r'[^a-z#+.\s]'
        return re.sub(char_gardes, '', texte)  



    def remove_sw(self, texte, return_verbs, return_token):

        doc = self.nlp(texte)

        if return_verbs :

            tokens = [token for token in doc if \
                      token.is_stop == False and token.is_punct == False\
                      and token.is_space == False
                     ]

        else :

            tokens = [token for token in doc if \
                      token.is_stop == False and token.is_punct == False\
                      and token.pos_ != "VERB"\
                      and token.is_space == False
                     ]

        if return_token :

            return tokens

        txt = ""

        for t in tokens :

            txt = txt + " " + t.text
            txt = txt.lstrip()

        return txt



    def pipe_clsw(self, texte, return_verbs = True, return_token = True):
        """
        Nettoye et enlève les SW d'un text/str et retourne une liste de tokens.
        Par défaut : 
        - On garde les verbe. Si False on les élimine du résultat.
        - On retourne une liste de token. Si False on retourne une str des tokens.
        """

        res = self.remove_sw(self.clean_text(texte), return_verbs, return_token)

        return res



    def make_gensim_vectors(self, corpus, model) :

        liste_vect_totale = []

        for texte in corpus:

            list_vect_text = []

            for mot in texte :

                list_vect_text.append(model[mot])

            list_vect_text = np.array(list_vect_text)
            vect_text = np.mean(list_vect_text, axis = 0)


            liste_vect_totale.append(vect_text)

        return np.array(liste_vect_totale)

 

    def text_from_tok(self, corpus):
    
        new_corpus = []

        for quest in corpus :

            new_quest = [tok.text for tok in quest]
            new_corpus.append(new_quest)

        return new_corpus



    def clean_for_gensim(self, corpus):

        clean_corpus = []

        #lex = model_google.vocab.keys()

        for texte in corpus :

            new_text = []

            for w in texte :

                if w in self.lexique :

                    new_text.append(w)

            # pour éviter l'ajout d'une valeur NAN à notre tableau...
            if len(new_text) == 0 :
                clean_corpus.append(['error'])
            else :
                clean_corpus.append(new_text)   

        return clean_corpus





# Utilisation
texte = "Entrez le texte de la question ici"

predicator = SO_Tag_Predictor()

tags = predicator.tag_one_question(texte)

print(tags)




